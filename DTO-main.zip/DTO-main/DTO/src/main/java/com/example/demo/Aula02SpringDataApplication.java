package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Aula02SpringDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(Aula02SpringDataApplication.class, args);
	}

}
